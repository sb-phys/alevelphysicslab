# 20/07/24 updated version of APL

A Pen created on CodePen.io. Original URL: [https://codepen.io/Selman-YB/pen/WNqrWMg](https://codepen.io/Selman-YB/pen/WNqrWMg).

